import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix

# =================================================================
# UYGULAMA 1: VERİ KÜMESİ ANATOMİSİ VE NORMALİZASYON
# =================================================================
print("\n===== UYGULAMA 1: VERİ KÜMESİ ANATOMİSİ =====")

# Veri kümelerini yükleme
mnist = tf.keras.datasets.mnist
(X_train_mnist, y_train_mnist), (X_test_mnist, y_test_mnist) = mnist.load_data()

fashion_mnist = tf.keras.datasets.fashion_mnist
(X_train_fashion, y_train_fashion), (X_test_fashion, y_test_fashion) = fashion_mnist.load_data()

cifar10 = tf.keras.datasets.cifar10
(X_train_cifar, y_train_cifar), (X_test_cifar, y_test_cifar) = cifar10.load_data()

print(f"MNIST Eğitim Seti Boyutu: {X_train_mnist.shape}")
print(f"Fashion-MNIST Eğitim Seti Boyutu: {X_train_fashion.shape}")
print(f"CIFAR-10 Eğitim Seti Boyutu: {X_train_cifar.shape}")


# =================================================================
# UYGULAMA 2: CONV2D VE PADDING STRATEJİLERİ (DOĞRULAMA)
# =================================================================
print("\n===== UYGULAMA 2: CONV2D VE PADDING DOĞRULAMASI =====")

# Model 1: 28x28x1 Giriş | 3x3 Kernel | Stride 1 | Valid Padding
model1 = tf.keras.models.Sequential([
    tf.keras.layers.InputLayer(input_shape=(28, 28, 1)),
    tf.keras.layers.Conv2D(filters=1, kernel_size=(3, 3), strides=1, padding='valid')
])
print("\n--- Model 1 (26x26 Bekleniyor) ---")
model1.summary()

# Model 2: 28x28x1 Giriş | 3x3 Kernel | Stride 1 | Same Padding
model2 = tf.keras.models.Sequential([
    tf.keras.layers.InputLayer(input_shape=(28, 28, 1)),
    tf.keras.layers.Conv2D(filters=1, kernel_size=(3, 3), strides=1, padding='same')
])
print("\n--- Model 2 (28x28 Bekleniyor) ---")
model2.summary()

# Model 3: 32x32x3 Giriş | 5x5 Kernel | Stride 2 | Valid Padding
model3 = tf.keras.models.Sequential([
    tf.keras.layers.InputLayer(input_shape=(32, 32, 3)),
    tf.keras.layers.Conv2D(filters=1, kernel_size=(5, 5), strides=2, padding='valid')
])
print("\n--- Model 3 (14x14 Bekleniyor) ---")
model3.summary()


# =================================================================
# UYGULAMA 3: POOLING VS STRIDE 2 (BİLGİ AZALTMA)
# =================================================================
print("\n===== UYGULAMA 3: POOLING VS STRIDE 2 =====")

# Yöntem 1: MaxPooling2D
model_pool = tf.keras.models.Sequential([
    tf.keras.layers.InputLayer(input_shape=(28, 28, 1)),
    tf.keras.layers.Conv2D(32, (3,3), padding='same', activation='relu'),
    tf.keras.layers.MaxPooling2D(pool_size=(2, 2))
])
print("\n--- Model: MaxPooling2D (0 Parametre) ---")
model_pool.summary()

# Yöntem 2: Stride=2
model_stride = tf.keras.models.Sequential([
    tf.keras.layers.InputLayer(input_shape=(28, 28, 1)),
    tf.keras.layers.Conv2D(32, (3,3), padding='same', activation='relu'),
    tf.keras.layers.Conv2D(32, (3,3), strides=2, padding='same', activation='relu')
])
print("\n--- Model: Conv2D(strides=2) (Öğrenilebilir) ---")
model_stride.summary()


# =================================================================
# UYGULAMA 4: UÇTAN UCA SINIFLANDIRMA (FASHION-MNIST)
# =================================================================
print("\n===== UYGULAMA 4: UÇTAN UCA SINIFLANDIRMA (FASHION-MNIST) =====")

# Veriyi hazırlama ve normalizasyon
X_train_f = X_train_fashion / 255.0
X_test_f = X_test_fashion / 255.0

X_train_f = X_train_f.reshape(-1, 28, 28, 1)
X_test_f = X_test_f.reshape(-1, 28, 28, 1)

# Föydeki mimariyi kurma
model_final = tf.keras.models.Sequential([
    tf.keras.layers.Conv2D(32, (3, 3), activation='relu', input_shape=(28, 28, 1)),
    tf.keras.layers.MaxPooling2D(2, 2),
    tf.keras.layers.Conv2D(64, (3, 3), activation='relu'),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(128, activation='relu'),
    tf.keras.layers.Dense(10, activation='softmax')
])

model_final.compile(optimizer='adam',
                    loss='sparse_categorical_crossentropy',
                    metrics=['accuracy'])

print("\nModel Eğitimi Başlıyor (5 Epoch)...")
model_final.fit(X_train_f, y_train_fashion, epochs=5, validation_data=(X_test_f, y_test_fashion))

# Hata Matrisi (Confusion Matrix)
y_pred = model_final.predict(X_test_f)
y_pred_classes = np.argmax(y_pred, axis=1)

class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']

cm = confusion_matrix(y_test_fashion, y_pred_classes)

plt.figure(figsize=(10, 8))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=class_names, yticklabels=class_names)
plt.title('Fashion-MNIST Hata Matrisi')
plt.ylabel('Gerçek Sınıflar')
plt.xlabel('Tahmin Edilen Sınıflar')
plt.show()