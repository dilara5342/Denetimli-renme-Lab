# import pandas as pd
# import numpy as np
# import matplotlib.pyplot as plt
# import seaborn as sns
# from sklearn import preprocessing
# from sklearn.model_selection import train_test_split
# from sklearn.neighbors import KNeighborsClassifier
# from sklearn import metrics
# from sklearn.metrics import confusion_matrix
#
# # --- 1. VERİ HAZIRLIĞI ---
# df = pd.read_csv('Lab07_teleCust1000t.csv')
# X = df[['region', 'tenure', 'age', 'marital', 'address', 'income', 'ed', 'employ', 'retire', 'gender', 'reside']].values
# y = df['custcat'].values
# X = preprocessing.StandardScaler().fit(X).transform(X.astype(float))
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=4)
#
#
# # =========================================================
# # BÖLÜM 1: TEKİL K İNCELEMESİ (KONTROL SENDE)
# # =========================================================
# K_DEGERI = 8  # Rapor için önce 4 yap, sonra 6 yapıp tekrar çalıştır!
#
# knn_model = KNeighborsClassifier(n_neighbors=K_DEGERI).fit(X_train, y_train)
# y_pred = knn_model.predict(X_test)
#
# print(f"\n==== K = {K_DEGERI} İÇİN ÖZEL SONUÇLAR ====")
# print("İlk 15 Tahmin (Prediction):", y_pred[0:15])
# print("Gerçek Değerler           :", y_test[0:15])
# print(f"Doğruluk Oranı (Accuracy) : % {metrics.accuracy_score(y_test, y_pred) * 100:.2f}")
#
# plt.figure(figsize=(6, 4))
# cm = confusion_matrix(y_test, y_pred)
# sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=[1,2,3,4], yticklabels=[1,2,3,4])
# plt.title(f'K = {K_DEGERI} İçin Karmaşıklık Matrisi')
# plt.xlabel('Tahmin Edilen Sınıf')
# plt.ylabel('Gerçek Sınıf')
#
# # KULLANICIYA UYARI:
# print("\n[ÖNEMLİ NOT]: Kodun geri kalanının (1-10 karşılaştırması) çalışması için,")
# print("Lütfen şu an ekranda açılan GRAFİK PENCERESİNİ KAPATINIZ (X tuşuna basınız)!")
# plt.show() # Bu satır, sen matrisi kapatana kadar kodu duraklatır!
#
#
# # =========================================================
# # BÖLÜM 2: 1'DEN 10'A KADAR K KARŞILAŞTIRMASI (MATRİSİ KAPATINCA ÇALIŞACAK)
# # =========================================================
# print("\n==== 1'DEN 10'A KADAR K KARŞILAŞTIRMASI ====")
# Ks = 10
# mean_acc = np.zeros((Ks))
#
# for n in range(1, Ks+1):
#     neigh = KNeighborsClassifier(n_neighbors=n).fit(X_train, y_train)
#     mean_acc[n-1] = metrics.accuracy_score(y_test, neigh.predict(X_test))
#     # Her K'nın doğruluk oranını ekrana basıyoruz
#     print(f"K={n} -> Doğruluk: % {mean_acc[n-1]*100:.2f}")
#
# en_iyi_k = mean_acc.argmax() + 1
# print(f"\n--> EN İYİ K DEĞERİ: {en_iyi_k} (Maksimum Doğruluk: % {mean_acc.max()*100:.2f})")
#
# # Karşılaştırma Grafiği
# plt.figure(figsize=(8, 5))
# plt.plot(range(1, Ks+1), mean_acc, marker='o', linestyle='dashed', color='red', markerfacecolor='black', markersize=8)
# plt.title('Farklı K Değerlerine Göre Model Doğruluğu (1-10 Arası)')
# plt.xlabel('K Değeri (Komşu Sayısı)')
# plt.ylabel('Doğruluk Oranı (Accuracy)')
# plt.xticks(np.arange(1, 11, step=1))
# plt.grid(True, linestyle='--', alpha=0.7)
# plt.show()

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
from sklearn.metrics import confusion_matrix

# =========================================================
# 1. VERİ YÜKLEME VE İNCELEME
# =========================================================
df = pd.read_csv('Lab07_teleCust1000t.csv')
print("==== 1. SINIF DAĞILIMI (custcat) ====")
print(df['custcat'].value_counts())
print("-" * 45)

# =========================================================
# 2. X-Y AYRIMI VE NORMALİZASYON
# =========================================================
X = df[['region', 'tenure', 'age', 'marital', 'address', 'income', 'ed', 'employ', 'retire', 'gender', 'reside']].values
y = df['custcat'].values
X = preprocessing.StandardScaler().fit(X).transform(X.astype(float))

print("==== 2. NORMALİZASYON İŞLEMİ ====")
print("Normalize edilmiş verinin İLK müşteriye ait özellikleri:")
print(X[0])
print("-" * 45)

# =========================================================
# 3. EĞİTİM (TRAIN) VE TEST OLARAK BÖLME
# =========================================================
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=4)
print("==== 3. TRAIN / TEST BOYUTLARI ====")
print("Eğitim (Train) seti boyutu :", X_train.shape, y_train.shape)
print("Test seti boyutu           :", X_test.shape, y_test.shape)
print("-" * 45)


# =========================================================
# 4. TEKİL K İNCELEMESİ (KONTROL SENDE)
# =========================================================
K_DEGERI = 4   # Rapor için önce 4 yap, sonra 6 yapıp tekrar çalıştır!

knn_model = KNeighborsClassifier(n_neighbors=K_DEGERI).fit(X_train, y_train)
y_pred = knn_model.predict(X_test)

print(f"\n==== 4. K = {K_DEGERI} İÇİN ÖZEL SONUÇLAR ====")
print("İlk 15 Tahmin (Prediction):", y_pred[0:15])
print("Gerçek Değerler           :", y_test[0:15])
print(f"Doğruluk Oranı (Accuracy) : % {metrics.accuracy_score(y_test, y_pred) * 100:.2f}")

# Karmaşıklık Matrisi Grafiği
plt.figure(figsize=(6, 4))
cm = confusion_matrix(y_test, y_pred)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=[1,2,3,4], yticklabels=[1,2,3,4])
plt.title(f'K = {K_DEGERI} İçin Karmaşıklık Matrisi')
plt.xlabel('Tahmin Edilen Sınıf')
plt.ylabel('Gerçek Sınıf')

# KULLANICIYA UYARI:
print("\n[ÖNEMLİ NOT]: 1'den 10'a kadar K karşılaştırmasının çalışması için,")
print("Lütfen şu an ekranda açılan GRAFİK PENCERESİNİ KAPATINIZ (X tuşuna basınız)!")
plt.show() # Sen pencereyi kapatana kadar bekler!


# =========================================================
# 5. 1'DEN 10'A KADAR K KARŞILAŞTIRMASI (MATRİSİ KAPATINCA ÇALIŞIR)
# =========================================================
print("\n==== 5. 1'DEN 10'A KADAR K KARŞILAŞTIRMASI ====")
Ks = 10
mean_acc = np.zeros((Ks))

for n in range(1, Ks+1):
    neigh = KNeighborsClassifier(n_neighbors=n).fit(X_train, y_train)
    mean_acc[n-1] = metrics.accuracy_score(y_test, neigh.predict(X_test))
    print(f"K={n} -> Doğruluk: % {mean_acc[n-1]*100:.2f}")

en_iyi_k = mean_acc.argmax() + 1
print(f"\n--> EN İYİ K DEĞERİ: {en_iyi_k} (Maksimum Doğruluk: % {mean_acc.max()*100:.2f})")

# Karşılaştırma Grafiği
plt.figure(figsize=(8, 5))
plt.plot(range(1, Ks+1), mean_acc, marker='o', linestyle='dashed', color='red', markerfacecolor='black', markersize=8)
plt.title('Farklı K Değerlerine Göre Model Doğruluğu (1-10 Arası)')
plt.xlabel('K Değeri (Komşu Sayısı)')
plt.ylabel('Doğruluk Oranı (Accuracy)')
plt.xticks(np.arange(1, 11, step=1))
plt.grid(True, linestyle='--', alpha=0.7)
plt.show()